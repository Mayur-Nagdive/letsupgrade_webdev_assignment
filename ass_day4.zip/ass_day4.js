//Author: Mayur Nagdive
//Date: 25 March 2021
//project: Web development essential day 4 assignment

//Fetched via tagname
var ele= document.getElementsByTagName('h1');
console.log(ele);
console.log(ele[0].innerText)
ele[0].innerText="Lets upgrade"

//fetched via classname
var rkr= document.getElementsByClassName('line');
console.log(rkr);
console.log(rkr[2].innerText)
rkr[2].innerText="This line was changed with the power of coding"

//fetched via id name
var tjt= document.getElementById('3');
console.log(tjt);
console.log(tjt.innerText)
tjt.innerText="The above line was changed with the power of coding";